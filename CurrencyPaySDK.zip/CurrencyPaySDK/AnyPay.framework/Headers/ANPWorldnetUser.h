//
//  ANPWorldnetUser.h
//  AnyPay
//
//  Created by Ankit Gupta on 24/01/18.
//  Copyright © 2018 Dan McCann. All rights reserved.
//

#import "ANPUser.h"

@interface ANPWorldnetUser : ANPUser

@end
